<?php 
header('charset=UTF8'); //文件用utf8编码，使得传输过去的中文字符可以被腾讯webservice识别
error_reporting(E_ALL ^ E_NOTICE);//忽略notice级别错误

$file = fopen('./test1.csv','r');//这是要读进来的包含地址的文件
$fp = fopen("test2.csv", "w");//这是要写入的csv文件


while ($data = fgetcsv($file)) {
	$strURL = iconv('GB2312', 'UTF-8', $data[0]);//csv默认是gbk，转为utf8格式
	$url = "http://apis.map.qq.com/ws/geocoder/v1/?address=".$strURL."&key=GTKBZ-HN6HF-BHGJ3-JWPWT-OYXXH-N2FMC";
	$html = json_decode(file_get_contents($url));//发送http请求，得到返回值

	//提取经纬度
	$data[1] = $html-> {'result'} -> {'location'} -> {'lng'};
	$data[2] = $html-> {'result'} -> {'location'} -> {'lat'};
	$location_list[] = $data;

	//存入csv文件
	fputcsv($fp, $data);
}

print_r($location_list);//打印在页面上
fclose($file);//关闭资源
fclose($fp);
?>